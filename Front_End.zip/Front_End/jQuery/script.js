// $(document).ready(function(){
// });
$(function(){

   $("#hidden").hover(function(){
    $(this).css("color", "black");
   },
   function() {
    $(this).hide();
   });
   $("#hidden").click(function(){
    $(this).css("color", "grey");
   });
   $("#b1").click(function(){
        alert("I'm alerting you!")
   });

   $("#about").click(function(){
    if($(this).html() === 'You Clicked me?'){
        $(this).html("Clicked me again!")
    }
    else{
    $(this).html("You Clicked me?")
    }
   });

   $("#about").hover(function(){
    $(this).css("background-color", "gold")
   });

   $("#about").mouseleave(function(){
    $(this).css("background-color", "lightsalmon")
   });

   $("#show").click(function(){
    $("#about").show();
   });

   $("#hide").click(function(){
    $("#about").hide();
   });

   $("#toggle").click(function(){
    $("#about").toggle();
   });
   
   $(".power").keyup(function(){
    $("#about").html($(this).val());
   });

   $("#getjson").click(function(){
    $.ajax({url: "games.json", success: function(result){
        $("#about").html(JSON.stringify(result,null,4));
   }});
   });

      $("#getgame").click(function(){
    $.ajax({url: "games.json", success: function(result){
        var game = result.games[1].title;
        $("#about").html(game);
   }});
   });

});