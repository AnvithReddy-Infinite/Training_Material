$(function () {
  function showTime() {
   
    var date = new Date();

  
    var hours = date.getHours();
    var min = date.getMinutes();
    var sec = date.getSeconds();


    var session = "AM";



    if (hours == 0) {
      hours = 12;
    }

    if (hours >= 12) {
      session = "PM";
    }

    if (hours > 12) {
      hours = hours - 12;
    }

    hours = hours < 10 ? "0" + hours : hours;
    min = min < 10 ? "0" + min : min;
    sec = sec < 10 ? "0" + sec : sec;



    $("#hours").text(hours);
    $("#min").text(min);
    $("#sec").text(sec);
    $("#period").text(session);

    var options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
    var today = date.toLocaleDateString("en-US", options);
    $("#date").text(today);


    setTimeout(showTime, 1000);
  }
  showTime();

  $("#showDateBtn").on("click", function () {
    $("#dateBox").fadeIn();
  });

  $("#hideDateBtn").on("click", function () {
    $("#dateBox").fadeOut();
  });
});

