-- 1) Display custid, name, age, orderid, orderdate for product Books or CD; sort by name DESC
SELECT c.custid, c.custname, c.age, o.orderid, o.orderdate
FROM customers c
JOIN orders o ON c.custid = o.custid
WHERE o.product IN ('Books','CD')
ORDER BY c.custname DESC;


-- 2) Find list of customers who live in the same city as Ajay; display custid, custname, price (price > 500)
SELECT c.custid, c.custname, o.price
FROM customers c
JOIN orders o ON c.custid = o.custid
WHERE c.caddress = (SELECT caddress FROM customers WHERE custname = 'Ajay')
  AND o.price > 500;


-- 3) Find the name of customers along with order details who purchased more than two products
SELECT c.custname, o.orderid, o.product, o.orderdate, o.price, o.qty
FROM customers c
JOIN orders o ON c.custid = o.custid
WHERE c.custid IN (
    SELECT custid FROM orders GROUP BY custid HAVING COUNT(*) > 2
);


-- 4) A discount of 20% has been announced to all customers who reside in Bangalore.
SELECT c.custid, c.custname, o.orderid,
       ROUND(o.price * 0.80, 2) AS DiscountPrice
FROM customers c
JOIN orders o ON c.custid = o.custid
WHERE c.caddress = 'Bangalore';


-- 5) Write a query to join three tables (create products table for the same)
IF OBJECT_ID('dbo.products', 'U') IS NULL
BEGIN
    CREATE TABLE products (
        productid INT IDENTITY(1,1) PRIMARY KEY,
        productname VARCHAR(100) UNIQUE,
        category VARCHAR(50)
    );
    INSERT INTO products (productname, category) VALUES
      ('Books','Stationery'),
      ('Laptop','Electronics'),
      ('Mobile','Electronics'),
      ('Pen','Stationery'),
      ('Chair','Furniture'),
      ('Table','Furniture'),
      ('Camera','Electronics');
END

-- Now join customers, orders, products (matching orders.product = products.productname)
SELECT c.custid, c.custname, o.orderid, o.product, p.category, o.price, o.qty
FROM customers c
JOIN orders o ON c.custid = o.custid
JOIN products p ON o.product = p.productname;


-- 6) Update price by 5% in orders table for customers who reside in Pune and Chennai
UPDATE orders
SET price = ROUND(price * 1.05, 2)
WHERE custid IN (
    SELECT custid FROM customers WHERE caddress IN ('Pune','Chennai')
);


-- 7) Create a report in following format:
-- Custidord Custname Product Price orderdate
-- Example Custidord: 'cid:100-ordid:10'
-- Requirements:
--  1) Custname should be uppercase
--  2) Display only first 3 character of product
--  3) The report should be of December 2000
SELECT
  'cid:' + CAST(c.custid AS VARCHAR(10)) + '-ordid:' + CAST(o.orderid AS VARCHAR(10)) AS Custidord,
  UPPER(c.custname) AS Custname,
  LEFT(o.product, 3) AS Product,
  o.price AS Price,
  CONVERT(VARCHAR(10), o.orderdate, 101) AS orderdate
FROM customers c
JOIN orders o ON c.custid = o.custid
WHERE YEAR(o.orderdate) = 2000 AND MONTH(o.orderdate) = 12
ORDER BY c.custid, o.orderdate;

------------------------------------------------------------------------------------------------------------
--Validations:
USE ShopDB;


-- Students table 
CREATE TABLE dbo.Students
(
    SeqID INT IDENTITY(1,1) NOT NULL,            -- internal identity
    StudentRollNumber AS (SeqID * 100) PERSISTED PRIMARY KEY, -- 100,200,300...
    StudentName VARCHAR(200) NOT NULL,
    DOB DATE NOT NULL,
    Class TINYINT NOT NULL,
    CONSTRAINT CHK_Students_DOB_NotFuture CHECK (DOB <= CONVERT(DATE, GETDATE())),
    CONSTRAINT CHK_Students_Class_Range CHECK (Class BETWEEN 1 AND 10)
);


-- Stock table 
CREATE TABLE dbo.Stock
(
    StockId VARCHAR(20) NOT NULL PRIMARY KEY,
    MinStockLvl INT NOT NULL,
    MaxStockLvl INT NOT NULL,
    CONSTRAINT CHK_Stock_MaxGreaterMin CHECK (MaxStockLvl > MinStockLvl),
    CONSTRAINT CHK_StockId_Format CHECK (
        StockId LIKE '[A-Za-z][A-Za-z][A-Za-z]-[0-9][0-9]-[A-Za-z][A-Za-z][A-Za-z]'
    )
);

-- Purchase table 
CREATE TABLE dbo.Purchase
(
    ProductId VARCHAR(100) NOT NULL,
    PurchaseDate DATE NOT NULL CONSTRAINT DF_Purchase_PurchaseDate DEFAULT (CONVERT(DATE, GETDATE())),
    SerialNo VARCHAR(100) NOT NULL UNIQUE,
    Price DECIMAL(12,2) NOT NULL,
    Qty INT NOT NULL,
    Total AS (Price * Qty) PERSISTED,
    CONSTRAINT CHK_Purchase_Qty_GT1 CHECK (Qty > 1),
    CONSTRAINT CHK_Purchase_Price_Range CHECK (Price BETWEEN 1000 AND 7000)
);

