--================ FUNCTIONS ASSIGNMENT ================
--1) create a function to find the greatest of three numbers
CREATE FUNCTION fn_MaxOfThree (@a INT,@b INT,@c INT)
RETURNS INT
AS
BEGIN
DECLARE @m INT;
SET @m = @a;
IF @b > @m SET @m = @b;
IF @c > @m SET @m = @c;
RETURN @m;
END;
GO
SELECT dbo.fn_MaxOfThree(10,25,15) AS MaxValue;
GO


--2) create a function to calculate to discount of 10 on price on all the products
CREATE FUNCTION fn_FlatTenDiscount (@price DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
DECLARE @newPrice DECIMAL(10,2);
SET @newPrice = @price - (@price * 10 / 100.0);
RETURN @newPrice;
END;
GO
SELECT dbo.fn_FlatTenDiscount(500.00) AS DiscountedPrice;
GO

--3) create a function to calculate the discount on price as following if productname books then 10 if productname toys then 15 else no discount
CREATE FUNCTION fn_DiscountByProduct (@productname VARCHAR(50))
RETURNS @tbl TABLE
(
custid INT,
product VARCHAR(50),
originalprice DECIMAL(10,2),
discountprice DECIMAL(10,2)
)
AS
BEGIN
IF @productname = 'Books'
INSERT @tbl
SELECT custid,product,price,price * 0.90
FROM orders
WHERE product = 'Books';
ELSE IF @productname = 'Toys'
INSERT @tbl
SELECT custid,product,price,price * 0.85
FROM orders
WHERE product = 'Toys';
ELSE
INSERT @tbl
SELECT custid,product,price,price
FROM orders
WHERE product = @productname;
RETURN;
END;
GO
SELECT * FROM dbo.fn_DiscountByProduct('Books');
SELECT * FROM dbo.fn_DiscountByProduct('Toys');
GO


--4) create inline function which accepts number and prints last n years of orders made from now. pass n as a parameter
CREATE FUNCTION fn_LastNYearsOrders (@n INT)
RETURNS TABLE
AS
RETURN
(
SELECT custid,orderid,orderdate,product,price,qty
FROM orders
WHERE orderdate >= DATEADD(YEAR,-@n,GETDATE())
);
GO
SELECT * FROM dbo.fn_LastNYearsOrders(3);
GO