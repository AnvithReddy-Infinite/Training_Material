USE ShopDB;
-- 1) Show students table rows
SELECT * FROM dbo.Students;

-- 2) Create view v1 (shows roll, name, dob)
IF OBJECT_ID('dbo.v1','V') IS NOT NULL
    DROP VIEW dbo.v1;

CREATE VIEW dbo.v1
AS
SELECT StudentRollNumber, StudentName, DOB
FROM dbo.Students;

-- 3) Read rows from view v1
SELECT * FROM dbo.v1;

-- 4) Insert a new student into base table (SeqID identity will generate roll 100/200 etc.)
INSERT INTO dbo.Students (StudentName, DOB, Class)
VALUES ('Anvith', '2004-04-11', 10);

-- 5) Update student's name (example: change name of the student having StudentRollNumber = 100)
UPDATE dbo.Students
SET StudentName = 'Lucky'
WHERE StudentRollNumber = 100;

-- 6) Delete row from Students
DELETE FROM dbo.Students
WHERE StudentName = 'Anvith';

-- 7) Drop view v1
DROP VIEW IF EXISTS dbo.v1;

-- 8) Show view definition (if not encrypted)
EXEC sp_helptext 'dbo.v1';
EXEC sp_depends 'dbo.Students';

-- 10) Create view v1 with encryption (definition will be hidden)
IF OBJECT_ID('dbo.v1','V') IS NOT NULL
    DROP VIEW dbo.v1;


CREATE VIEW dbo.v1
WITH ENCRYPTION
AS
SELECT StudentName, DOB
FROM dbo.Students;

EXEC sp_helptext 'dbo.v1';

-- 12) Create view v2 (example filter). This view selects columns only; inserting into v2 will work only if required NOT NULL columns have defaults.
IF OBJECT_ID('dbo.v2','V') IS NOT NULL
    DROP VIEW dbo.v2;


CREATE VIEW dbo.v2
AS
SELECT StudentName, DOB, Class   -- include Class so inserts can provide it via the view
FROM dbo.Students
WHERE StudentName = 'Anvith';

ALTER VIEW dbo.v2
AS
SELECT StudentName, DOB, Class
FROM dbo.Students
WHERE StudentName = 'Anvith'
WITH CHECK OPTION;

INSERT INTO dbo.v2 (StudentName, DOB, Class)
VALUES ('Anvith', '2004-04-11', 8);

DELETE FROM dbo.Students WHERE StudentName = 'Anvith';

-----------------------------------------------------------------------------------
-- 1) Create / reset dbo.studentstbl and insert sample rows
IF OBJECT_ID('dbo.studentstbl','U') IS NOT NULL
    DROP TABLE dbo.studentstbl;


CREATE TABLE dbo.studentstbl
(
    studentid INT IDENTITY(1,1) PRIMARY KEY,
    studentname VARCHAR(100) NOT NULL,
    age INT NOT NULL
);


INSERT INTO dbo.studentstbl (studentname, age) VALUES
('Ajay', 23),
('Monika', 22),
('Ravi', 20);


-- 2) Create / reset dbo.newstudentstbl (used for schemabinding example)
IF OBJECT_ID('dbo.newstudentstbl','U') IS NOT NULL
    DROP TABLE dbo.newstudentstbl;

CREATE TABLE dbo.newstudentstbl
(
    studentid INT IDENTITY(1,1) PRIMARY KEY,
    studentname VARCHAR(100) NOT NULL,
    age INT NOT NULL
);


INSERT INTO dbo.newstudentstbl (studentname, age) VALUES
('Kiran', 22),
('Sonia', 19);


--- Step 3 FIXED: Drop v1 if exists, then create v1 in its own batch with ENCRYPTION
IF OBJECT_ID('dbo.v1','V') IS NOT NULL
    DROP VIEW dbo.v1;
GO

CREATE VIEW dbo.v1
WITH ENCRYPTION
AS
SELECT studentid, studentname, age
FROM dbo.studentstbl;
GO

-- 4) Read from v1 (you can still select from it)
SELECT * FROM dbo.v1;


-- 5) Create view v2 with check option (only rows with age = 22 allowed via this view)
IF OBJECT_ID('dbo.v2','V') IS NOT NULL
    DROP VIEW dbo.v2;
GO

CREATE VIEW dbo.v2
AS
SELECT studentid, studentname, age
FROM dbo.studentstbl
WHERE age = 22
WITH CHECK OPTION;
GO

-- 6a) Insert via v2 with age = 22 (should succeed)
INSERT INTO dbo.v2 (studentname, age)
VALUES ('Test22', 22);
GO

-- 6b) Insert via v2 with age != 22 (will fail due to WITH CHECK OPTION)
INSERT INTO dbo.v2 (studentname, age)
VALUES ('BadInsert', 21);
GO

-- 7) Create view v3 WITH SCHEMABINDING (protects underlying table schema)
IF OBJECT_ID('dbo.v3','V') IS NOT NULL
    DROP VIEW dbo.v3;
GO

CREATE VIEW dbo.v3
WITH SCHEMABINDING
AS
SELECT studentid, studentname, age
FROM dbo.newstudentstbl;
GO

-- 8) Create view v_all WITH ENCRYPTION, SCHEMABINDING and WITH CHECK OPTION
IF OBJECT_ID('dbo.v_all','V') IS NOT NULL
    DROP VIEW dbo.v_all;
GO

CREATE VIEW dbo.v_all
WITH ENCRYPTION, SCHEMABINDING
AS
SELECT studentid, studentname, age
FROM dbo.studentstbl
WHERE age = 22
WITH CHECK OPTION;
GO

-- 9a) Show rows from v_all (should include only age = 22)
SELECT * FROM dbo.v_all;
GO

-- 9b) Try inserting via v_all with age = 22 (should succeed)
INSERT INTO dbo.v_all (studentname, age) VALUES ('ViaVAll', 22);
GO

-- 9c) Try inserting via v_all with age != 22 (should fail)
INSERT INTO dbo.v_all (studentname, age) VALUES ('ViaVAllBad', 21);
GO

-- 9d) Try to see view definition (will not show because v_all was created WITH ENCRYPTION)
EXEC sp_helptext 'dbo.v_all';
GO

-- 9e) Try to drop underlying table (will fail because of schemabinding)
-- DROP TABLE dbo.studentstbl;    -- (uncomment only to see the error)

---------------------------------
-- Create a view using ENCRYPTION + SCHEMABINDING + CHECK OPTION
IF OBJECT_ID('dbo.v_all','V') IS NOT NULL
    DROP VIEW dbo.v_all;
GO

CREATE VIEW dbo.v_all
WITH ENCRYPTION, SCHEMABINDING
AS
SELECT studentid, studentname, age
FROM dbo.studentstbl
WHERE age = 22
WITH CHECK OPTION;
GO

SELECT * FROM dbo.v_all;  
EXEC sp_helptext 'dbo.v_all';  --will NOT show definition

INSERT INTO dbo.v_all (studentname, age)
VALUES ('Test22', 22);   --works

INSERT INTO dbo.v_all (studentname, age)
VALUES ('BadAge', 20);   --fails due to CHECK OPTION

------------------------------------------------

-- Create view to find studentname containing underscore
IF OBJECT_ID('dbo.v_contains_underscore','V') IS NOT NULL
    DROP VIEW dbo.v_contains_underscore;
GO

CREATE VIEW dbo.v_contains_underscore
AS
SELECT studentid, studentname, age
FROM dbo.studentstbl
WHERE studentname LIKE '%\_%' ESCAPE '\';
GO

SELECT * FROM dbo.v_contains_underscore;

INSERT INTO dbo.studentstbl (studentname, age)
VALUES ('Ravi_Reddy', 23);

-----------------------------------------------

declare @a int
set @a=5
if @a=5
print '5'
else
print '10'


declare @c int ,@b int
set @c=5
set @b=10
print @c+@b


--greatest of 2 numbers
 
declare @m int ,@n int
set @m=15
set @n=10
if(@m>@n)
begin
print 'the greatest number '+ cast(@m as varchar)
print concat('the greatest is ',@m)
print 'hello' 
end
else
print @n
 
 --loops(while)
declare @x int
set @x=0
while(@x<10)
begin
set @x=@x+1
print @x
if(@x=5)
break
end

--switch
select custid,custname,age,
case 
when age<18 then 'minor'
when age between 18 and 40 then 'adult'
when age between 41 and 60 then 'middle aged'
else 'senior'
end as agecategory
from customers;

--ranking
 
CREATE TABLE EmployeeSales (
    EmpId INT PRIMARY KEY,
    EmpName VARCHAR(50),
    Department VARCHAR(50),
    SalesAmount INT,
    SalesMonth VARCHAR(20)
);
 
INSERT INTO EmployeeSales VALUES
(1, 'Amit',   'IT',        50000, 'January'),
(2, 'Neha',   'IT',        75000, 'January'),
(3, 'Rohit',  'IT',        75000, 'January'), 
(4, 'Kiran',  'IT',        30000, 'January'),
(5, 'Pooja',  'HR',        40000, 'January'),
(6, 'Sanjay', 'HR',        40000, 'January'),
(7, 'Meera',  'HR',        60000, 'January'),
(8, 'Vinay',  'Sales',     90000, 'January'),
(9, 'Simran', 'Sales',     85000, 'January'),
(10,'John',   'Sales',     85000, 'January');
 
SELECT 
    EmpName, Department, SalesAmount,
    rank() OVER( ORDER BY SalesAmount DESC) AS RankInDept1,
	dense_rank() OVER( ORDER BY SalesAmount DESC) AS RankInDept2,
	row_number() OVER( ORDER BY SalesAmount DESC) AS RankInDept3
FROM EmployeeSales


--error handling
--declare @a1 int
--set @a1=10
--print @a1/0
--print @@error
--if(@@error=8134)
--print 'you are trying to divide 0.. pls check again'
--to print built in methods

begin try
declare @a1 int
set @a1=10
print @a1/0
end try
begin catch
print 'you are trying to divide 0.. pls check'
print error_message()
print error_line()
print error_number()
print error_severity()
print error_procedure()
 
end catch





 















