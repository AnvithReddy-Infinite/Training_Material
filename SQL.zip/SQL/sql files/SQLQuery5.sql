-- 1) Create the database and switch to it:
CREATE DATABASE ShopDB;
USE ShopDB;

-- 2) Create Customers Table:
CREATE TABLE customers (
  custid INT PRIMARY KEY,
  custname VARCHAR(100),
  age INT,
  caddress VARCHAR(200),
  cphone VARCHAR(20)
);

-- 3) Create the orders table
CREATE TABLE orders (
  custid INT,
  orderid INT,
  orderdate DATE,
  product VARCHAR(100),
  price DECIMAL(10,2),
  qty INT,
  CONSTRAINT PK_orders PRIMARY KEY (orderid, custid),
  CONSTRAINT FK_orders_customers FOREIGN KEY (custid) REFERENCES customers(custid)
);

-- 4) Insert Customer Records
INSERT INTO customers VALUES (100, 'Ajay', 23, 'Bangalore', '87878787');
INSERT INTO customers VALUES 
(101, 'Priya Sharma', 45, 'Chennai', '98989898'),
(102, 'Asha', 52, 'Bangalore', '77777777'),
(103, 'Suresh', 61, 'Mumbai', '66666666'),
(104, 'Manoj', 35, 'Delhi', '55555555'),
(105, NULL, 28, 'Hyderabad', '44444444');

-- 5) Insert the orders data.
INSERT INTO orders VALUES
(100, 10, '2025-01-01', 'Books', 120.00, 3),
(100, 11, '2019-05-10', 'Laptop', 45000.00, 1),
(101, 12, '2018-03-15', 'Mobile', 15000.00, 2),
(102, 13, '2024-06-20', 'Pen', 10.00, 200),
(103, 14, '2015-11-30', 'Chair', 3000.00, 4),
(104, 15, '2023-02-01', 'Table', 7000.00, 60),
(104, 16, '2020-12-01', 'Books', 200.00, 150),
(105, 17, '2025-10-10', 'Camera', 5000.00, 1);

-- 6) Assignment Question 1: Display the list of customers who reside in Bangalore
SELECT * FROM customers WHERE caddress = 'Bangalore';

--7) Assignment Question 2: Display the list of customers who do NOT reside in Bangalore or Chennai
SELECT * FROM customers 
WHERE caddress NOT IN ('Bangalore', 'Chennai');

--8) Assignment Question 3: Display customers whose age is greater than 50 and do not reside in Bangalore
SELECT * FROM customers 
WHERE age > 50 AND caddress <> 'Bangalore';

-- 9) Assignment Question 4: Display customers whose name starts with A
SELECT * FROM customers 
WHERE custname LIKE 'A%';

-- 10) Assignment Question 5: Display customers whose name contains substring 'Br'
SELECT * FROM customers 
WHERE custname LIKE '%Br%';

-- 11) Assignment Question 6: Display customers whose name starts between 'A' and 'K'
SELECT * FROM customers
WHERE LEFT(UPPER(ISNULL(custname,'')),1) BETWEEN 'A' AND 'K';

-- 12) Assignment Question 7: Display customers whose name is 5 characters long
SELECT * FROM customers 
WHERE LEN(custname) = 5;

-- 13) Assignment Question 8: Name starts with 's', 3rd character is 'c', and ends with 'e'
SELECT * FROM customers
WHERE custname LIKE 's_c%e';

-- 14) Assignment Question 9: Display unique customer names
SELECT DISTINCT custname 
FROM customers;

-- 15) Assignment Question 10: Orders with qty 100�200 or 700�1200
SELECT * FROM orders 
WHERE (qty BETWEEN 100 AND 200) 
   OR (qty BETWEEN 700 AND 1200);

-- 16) Assignment Question 11: custname beginning with 'AL' and ending with 'N'
SELECT * FROM customers 
WHERE custname LIKE 'AL%N';

-- 17) Assignment Question 12: 20% price increase, show custid, old price, new price
SELECT custid AS CustomerID, 
       price AS OldPrice,
       ROUND(price * 1.20, 2) AS NewPrice
FROM orders;

-- 18) Assignment Question 13: Top 3 highest qty
SELECT TOP (3) * 
FROM orders 
ORDER BY qty DESC

-- 19) Assignment Question 14: How many times each customer purchased (count of orders)
SELECT custid, COUNT(*) AS PurchaseCount
FROM orders
GROUP BY custid;

-- 20) Assignment Question 15: Orders made earlier than 5 years from today
SELECT * FROM orders 
WHERE orderdate < DATEADD(year, -5, GETDATE())

-- 21) Assignment Question 16: Customers where custname is NULL
SELECT * FROM customers 
WHERE custname IS NULL;

-- 22) Assignment Question 17: Order details in format OrderID-Date and Total(price*qty)
SELECT 
    CAST(orderid AS VARCHAR(20)) + ' - ' + CONVERT(VARCHAR(10), orderdate, 103) AS OrderID_Date,
    (price * qty) AS Total
FROM orders;

-- 23) Assignment Question 18: Decrease price by 20% for qty > 50
UPDATE orders 
SET price = ROUND(price * 0.80, 2)
WHERE qty > 50;

-- 24) Assignment Question 19: Orders on '1990-12-01' with price between 4000 and 6000, descending
SELECT * FROM orders
WHERE orderdate = '1990-12-01'
  AND price BETWEEN 4000 AND 6000
ORDER BY price DESC;

-- 25) Assignment Question 20: Custid, Price(sum), Count(qty)
SELECT custid, 
       SUM(price) AS PriceSum, 
       COUNT(qty) AS QtyCount
FROM orders
GROUP BY custid;

-- 26) Assignment Question 21: Same as above but only where price sum > 4000
SELECT custid, 
       SUM(price) AS PriceSum, 
       COUNT(qty) AS QtyCount
FROM orders
GROUP BY custid
HAVING SUM(price) > 4000;

-- 27) Assignment Question 22a: Create duplicate table custhistory
SELECT * INTO custhistory 
FROM customers 
WHERE 1 = 0;


-- 28) Assignment Question 22b: Delete all records of custhistory
TRUNCATE TABLE custhistory;


-- 29) Assignment Question 22c: Copy customers where age > 30
INSERT INTO custhistory
SELECT * FROM customers 
WHERE age > 30;


-- DAY 2 ASSIGNMENT 2 SUBQUERY:

-- 1) SubQuery: Display all records from customers who made a purchase of books
SELECT * FROM customers
WHERE custid IN (SELECT custid FROM orders WHERE product = 'Books');

-- 2) SubQuery: Display all records from customers who made a purchase of books, toys, or cd
SELECT * FROM customers
WHERE custid IN (SELECT custid FROM orders WHERE product IN ('Books','Toys','CD'));

-- 3) SubQuery: Display the list of customers who never made any purchase
SELECT * FROM customers
WHERE custid NOT IN (SELECT DISTINCT custid FROM orders);

-- 4) SubQuery: Display the second highest age from customers (do not use TOP)
SELECT MAX(age) AS SecondHighestAge
FROM customers
WHERE age < (SELECT MAX(age) FROM customers);

-- 5) SubQuery: Display list from orders where customers stay in Bangalore
SELECT * FROM orders
WHERE custid IN (SELECT custid FROM customers WHERE caddress = 'Bangalore');

-- 6) SubQuery: Display list of customers who made the lowest purchase (in terms of quantity)
SELECT * FROM customers
WHERE custid IN (
    SELECT custid 
    FROM orders 
    WHERE qty = (SELECT MIN(qty) FROM orders)
);

-- 7) SubQuery: Display customers whose age is greater than Ajay's age (without knowing Ajay's age)
SELECT * FROM customers
WHERE age > (
    SELECT age FROM customers WHERE custname = 'Ajay'
);

-- 8) SubQuery: Update customer table where 
-- custid = 100's age = custid = 200's age
UPDATE customers
SET age = (
    SELECT age FROM customers WHERE custid = 200
)
WHERE custid = 100;

-- 9) SubQuery: Display those order details where orders were made in December of any year
SELECT * FROM orders
WHERE MONTH(orderdate) = (
    SELECT 12
);

-- 10) SubQuery: Show all orders made before the 16th of the month (day < 16)
-- and customers do NOT reside in Bangalore
SELECT * FROM orders
WHERE DAY(orderdate) < (
        SELECT 16
    )
AND custid IN (
        SELECT custid FROM customers WHERE caddress <> 'Bangalore'
    );


-- 11) SubQuery: Display customers from Delhi or Bangalore 
-- who made purchase of less than 3 quantity
SELECT * FROM customers
WHERE caddress IN ('Delhi', 'Bangalore')
AND custid IN (
        SELECT custid FROM orders 
        WHERE qty < 3
    );


-- 12) SubQuery: Display list of orders where price is greater than average price
SELECT * FROM orders
WHERE price > (
    SELECT AVG(price) FROM orders
);


-- 13) SubQuery: Update orders table increasing price by 10% for customers residing in Bangalore and who purchased Books
UPDATE orders
SET price = ROUND(price * 1.10, 2)
WHERE product = 'Books'
  AND custid IN (SELECT custid FROM customers WHERE caddress = 'Bangalore');


-- 14) SubQuery: Display order details in format: OrderID-Date  Total(price*qty)
SELECT 
    CAST(orderid AS VARCHAR(10)) + '-' + 
    CONVERT(VARCHAR(10), orderdate, 101) AS [OrderID-Date],
    
    (SELECT price * qty FROM orders o2 WHERE o2.orderid = o1.orderid AND o2.custid = o1.custid)
    AS Total
FROM orders o1;














