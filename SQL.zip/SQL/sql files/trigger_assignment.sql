
--1) Trigger: do not allow delete for customers staying in Bangalore, Chennai, Delhi
CREATE TABLE CustMain(CustId INT PRIMARY KEY,CustName VARCHAR(50),City VARCHAR(50));
INSERT INTO CustMain VALUES(1,'Anvith','Vizag'),(2,'Ravi','Bangalore'),(3,'Sai','Chennai'), (4,'Shiva','Pune'), (5,'Ram','Delhi') ;
GO
CREATE TRIGGER trg_NoDelete_Cities ON CustMain
FOR DELETE
AS
IF EXISTS(SELECT 1 FROM deleted WHERE City IN('Bangalore','Chennai','Delhi'))
BEGIN
PRINT 'You cannot delete customers who stay in Bangalore, Chennai or Delhi';
ROLLBACK TRANSACTION;
END;
GO

--Sample Test
DELETE FROM CustMain WHERE CustId=2;
SELECT * FROM CustMain;
GO


--2) Trigger: for orders allow insert only Books, CD, Mobile
CREATE TABLE OrderMain(OrderId INT PRIMARY KEY,CustId INT,Product VARCHAR(50),Price DECIMAL(10,2),Qty INT);
GO
CREATE TRIGGER trg_OnlyAllowedProducts ON OrderMain
FOR INSERT
AS
IF EXISTS(SELECT 1 FROM inserted WHERE LOWER(Product) NOT IN('books','cd','mobile'))
BEGIN
PRINT 'Only Books, CD or Mobile are allowed as product';
ROLLBACK TRANSACTION;
END;
GO

--Sample Test
INSERT INTO OrderMain VALUES(101,1,'Books',500,2);
INSERT INTO OrderMain VALUES(102,1,'Laptop',45000,1);
SELECT * FROM OrderMain;
GO


--3) Trigger: when a customer is deleted, copy row to CustHistory2
CREATE TABLE CustHistory2(CustId INT,CustName VARCHAR(50),City VARCHAR(50));
GO
CREATE TRIGGER trg_Customer_To_History ON CustMain
FOR DELETE
AS
INSERT INTO CustHistory2(CustId,CustName,City)
SELECT CustId,CustName,City FROM deleted;
GO

--Sample Test
DELETE FROM CustMain WHERE CustId=3;
SELECT * FROM CustHistory2;
GO


--4) Update trigger for Stock2: display old and new values
CREATE TABLE Stock2(StockId VARCHAR(20) PRIMARY KEY,MinStock INT,MaxStock INT);
INSERT INTO Stock2 VALUES('ITM1',10,50);
GO
CREATE TRIGGER trg_Stock_Audit ON Stock2
FOR UPDATE
AS
BEGIN
PRINT 'Old values:';
SELECT StockId,MinStock,MaxStock FROM deleted;
PRINT 'New values:';
SELECT StockId,MinStock,MaxStock FROM inserted;
END;
GO

--Sample Test
UPDATE Stock2 SET MinStock=20,MaxStock=60 WHERE StockId='ITM1';
GO


--5) INSTEAD OF INSERT trigger on joined view to insert into 2 tables using single insert
CREATE TABLE TblA(CustId INT PRIMARY KEY,CustName VARCHAR(50));
CREATE TABLE TblB(CustId INT,Product VARCHAR(50));
GO
CREATE VIEW ViewA AS
SELECT a.CustId,a.CustName,b.Product
FROM TblA a INNER JOIN TblB b ON a.CustId=b.CustId;
GO
CREATE TRIGGER trg_View_Insert ON ViewA
INSTEAD OF INSERT
AS
BEGIN
INSERT INTO TblA(CustId,CustName)
SELECT i.CustId,i.CustName
FROM inserted i
WHERE NOT EXISTS(SELECT 1 FROM TblA x WHERE x.CustId=i.CustId);
INSERT INTO TblB(CustId,Product)
SELECT i.CustId,i.Product
FROM inserted i;
END;
GO

--Sample Test
INSERT INTO ViewA(CustId,CustName,Product)
VALUES(10,'Anvith','Mobile');
SELECT * FROM TblA;
SELECT * FROM TblB;
SELECT * FROM ViewA;
GO