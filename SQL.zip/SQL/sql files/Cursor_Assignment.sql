--1) basic cursor print all employee names: create a cursor on employees table to print each employee name
if object_id('CurEmployees') is not null drop table CurEmployees;
go
create table CurEmployees(empid int primary key,empname varchar(50),dept varchar(50),salary decimal(10,2));
go
insert into CurEmployees 
values
(1,'Anvith','IT',45000.00),
(2,'Ravi','HR',35000.00),
(3,'Sai','Finance',40000.00);
declare empcursor cursor for select empname from CurEmployees;
declare @EmpName varchar(50);
open empcursor;
fetch next from empcursor into @EmpName;
while @@fetch_status=0
begin
print 'Employee Name: ' + @EmpName;
fetch next from empcursor into @EmpName;
end;
close empcursor;
deallocate empcursor;



--2) cursor to update salary: increase each employee salary by 10% inside the cursor loop
declare salarycursor cursor for select empid,salary from CurEmployees;
declare @EmpId int,@Sal decimal(10,2);
open salarycursor;
fetch next from salarycursor into @EmpId,@Sal;
while @@fetch_status=0
begin
update CurEmployees set salary=@Sal+(@Sal*0.10) where empid=@EmpId;
fetch next from salarycursor into @EmpId,@Sal;
end;
close salarycursor;
deallocate salarycursor;
select * from CurEmployees;



--3) cursor with conditional logic: fetch all orders and give discount based on qty (>=10 : 5%, <10 : 2%)
if object_id('CurOrders') is not null drop table CurOrders;
go
create table CurOrders(orderid int primary key,custid int,product varchar(50),qty int,price decimal(10,2),discountedprice decimal(10,2));
go
insert into CurOrders(orderid,custid,product,qty,price) values
(101,901,'Books',5,500.00),
(102,901,'Mobile',12,15000.00),
(103,902,'Charger',8,800.00);
declare ordercursor cursor for select orderid,qty,price from CurOrders;
declare @Oid int,@Q int,@P decimal(10,2),@Disc decimal(10,2);
open ordercursor;
fetch next from ordercursor into @Oid,@Q,@P;
while @@fetch_status=0
begin
if @Q>=10
set @Disc=@P-(@P*0.05);
else
set @Disc=@P-(@P*0.02);
update CurOrders set discountedprice=@Disc where orderid=@Oid;
fetch next from ordercursor into @Oid,@Q,@P;
end;
close ordercursor;
deallocate ordercursor;
select * from CurOrders;



--4) cursor to copy data from one table to another: read from oldproducts and insert into newproducts
if object_id('OldProducts') is not null drop table OldProducts;
if object_id('NewProducts') is not null drop table NewProducts;
go
create table OldProducts(productid int primary key,productname varchar(50),price decimal(10,2));
create table NewProducts(productid int primary key,productname varchar(50),price decimal(10,2));
go
insert into OldProducts values(1,'Books',500.00),(2,'Mobile',15000.00),(3,'Laptop',45000.00);
declare prodcursor cursor for select productid,productname,price from OldProducts;
declare @Pid int,@Pname varchar(50),@Pprice decimal(10,2);
open prodcursor;
fetch next from prodcursor into @Pid,@Pname,@Pprice;
while @@fetch_status=0
begin
insert into NewProducts(productid,productname,price) values(@Pid,@Pname,@Pprice);
fetch next from prodcursor into @Pid,@Pname,@Pprice;
end;
close prodcursor;
deallocate prodcursor;
select * from NewProducts;




--5) cursor to delete specific rows: delete customers whose lastorderdate is more than 2 years old
if object_id('CurCustomers') is not null drop table CurCustomers;
go
create table CurCustomers(custid int primary key,custname varchar(50),lastorderdate date);
go
insert into CurCustomers values(1,'Anvith','2021-01-10'),(2,'Ravi','2024-05-20'),(3,'Sai','2022-02-15');
declare custcursor cursor for select custid,lastorderdate from CurCustomers;
declare @Cid int,@LastDt date;
open custcursor;
fetch next from custcursor into @Cid,@LastDt;
while @@fetch_status=0
begin
if datediff(year,@LastDt,getdate())>2
delete from CurCustomers where custid=@Cid;
fetch next from custcursor into @Cid,@LastDt;
end;
close custcursor;
deallocate custcursor;
select * from CurCustomers;

