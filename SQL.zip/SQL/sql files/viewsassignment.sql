

CREATE TABLE Employees (
 EmpId INT PRIMARY KEY,
 EmpName VARCHAR(100),
 DeptId INT,
 ManagerId INT,
 JoinDate DATE,
 Salary DECIMAL(10,2)
);

CREATE TABLE Departments (
 DeptId INT PRIMARY KEY,
 DeptName VARCHAR(100)
);

CREATE TABLE Sales (
 SaleId INT PRIMARY KEY,
 EmpId INT,
 Region VARCHAR(50),
 SaleAmount DECIMAL(10,2),
 SaleDate DATE
);

CREATE TABLE Transactions (
 TransId INT PRIMARY KEY,
 AccountId INT,
 Amount DECIMAL(10,2),
 TransDate DATE
);

INSERT INTO Employees VALUES
(1,'Amit',10,NULL,'2020-01-10',65000),
(2,'Neha',10,1,'2022-02-15',50000),
(3,'Ravi',20,1,'2023-03-12',45000),
(4,'Sana',20,3,'2024-01-20',42000),
(5,'Karan',30,1,'2021-07-18',55000);

INSERT INTO Departments VALUES
(10,'IT'),
(20,'HR'),
(30,'Finance');

INSERT INTO Sales VALUES
(1,1,'North',100000,'2024-01-01'),
(2,2,'North',90000,'2024-01-10'),
(3,3,'South',120000,'2024-02-05'),
(4,4,'South',120000,'2024-02-20'),
(5,5,'North',110000,'2024-03-15');

INSERT INTO Transactions VALUES
(1,101,1000,'2024-01-01'),
(2,101,2000,'2024-02-01'),
(3,101,-500,'2024-03-01'),
(4,102,1500,'2024-01-15'),
(5,102,-200,'2024-03-10');

-- TASK 1: SALARY CATEGORY USING CASE
SELECT EmpId,EmpName,Salary,
CASE
 WHEN Salary<20000 THEN 'Low'
 WHEN Salary BETWEEN 20000 AND 50000 THEN 'Medium'
 WHEN Salary>50000 THEN 'High'
END AS SalaryCategory
FROM dbo.Employees;

-- TASK 2: IF ELSE USING VARIABLE
DECLARE @Age INT=25;
IF @Age<18 PRINT 'Minor';
ELSE IF @Age BETWEEN 18 AND 60 PRINT 'Adult';
ELSE PRINT 'Senior';

-- TASK 3: ENCRYPTED AND SCHEMABINDING VIEW
IF OBJECT_ID('v_employee_secure','V') IS NOT NULL DROP VIEW v_employee_secure;
GO
CREATE VIEW v_employee_secure
WITH ENCRYPTION,SCHEMABINDING
AS
SELECT e.EmpId,e.EmpName,e.DeptId,e.JoinDate,e.Salary,(e.Salary*12) AS AnnualSalary
FROM dbo.Employees e
JOIN dbo.Departments d ON e.DeptId=d.DeptId;
GO

-- TASK 4: VIEW FOR TOTAL SALES AND RANK
IF OBJECT_ID('v_sales_rank','V') IS NOT NULL DROP VIEW v_sales_rank;
GO
CREATE VIEW v_sales_rank
AS
SELECT e.EmpId,e.EmpName,ISNULL(SUM(s.SaleAmount),0) AS TotalSales,
RANK() OVER(ORDER BY ISNULL(SUM(s.SaleAmount),0) DESC) AS RankByTotalSales
FROM dbo.Employees e
LEFT JOIN dbo.Sales s ON e.EmpId=s.EmpId
GROUP BY e.EmpId,e.EmpName;
GO

-- TASK 5: TRY CATCH DIVIDE BY ZERO
BEGIN TRY
DECLARE @a INT=10,@b INT=0;
SELECT @a/@b;
END TRY
BEGIN CATCH
PRINT 'ERROR: '+ERROR_MESSAGE();
END CATCH;

-- TASK 6: TRY CATCH WITH THROW
DECLARE @SalaryTest DECIMAL(10,2)=900;
BEGIN TRY
IF @SalaryTest<1000 THROW 50000,'Invalid Salary',1;
PRINT 'Salary OK';
END TRY
BEGIN CATCH
PRINT ERROR_MESSAGE();
END CATCH;

-- TASK 7: RANK BY REGION
SELECT s.Region,e.EmpId,e.EmpName,SUM(s.SaleAmount) AS TotalSales,
RANK() OVER(PARTITION BY s.Region ORDER BY SUM(s.SaleAmount) DESC) AS Rnk,
DENSE_RANK() OVER(PARTITION BY s.Region ORDER BY SUM(s.SaleAmount) DESC) AS DRnk,
ROW_NUMBER() OVER(PARTITION BY s.Region ORDER BY SUM(s.SaleAmount) DESC) AS RowNum
FROM dbo.Sales s
JOIN dbo.Employees e ON e.EmpId=s.EmpId
GROUP BY s.Region,e.EmpId,e.EmpName;

-- TASK 8: TOP 3 REGIONS USING CTE
WITH RegionTotals AS (
SELECT Region, SUM(SaleAmount) AS TotalSales
FROM Sales   
GROUP BY Region
),
Ranked AS (
SELECT Region, TotalSales,
RANK() OVER(ORDER BY TotalSales DESC) AS Rnk
FROM RegionTotals
)
SELECT Region, TotalSales, Rnk
FROM Ranked
WHERE Rnk <= 3;


-- TASK 9: PAGINATION
WITH Ordered AS (
SELECT EmpId, EmpName, DeptId, ManagerId, JoinDate, Salary,
ROW_NUMBER() OVER(ORDER BY EmpId) AS rn
FROM Employees
)
SELECT *
FROM Ordered
WHERE rn BETWEEN 6 AND 10
ORDER BY rn;

 
