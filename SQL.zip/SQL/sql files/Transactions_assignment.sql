--1) Basic Transaction Commit / Rollback: Create a table BankAccount, transfer money, rollback if balance negative

CREATE TABLE BankAccount(AccountNo INT PRIMARY KEY,HolderName VARCHAR(50),Balance DECIMAL(10,2));
INSERT INTO BankAccount VALUES(101,'Anvith',20000.00),(102,'Ravi',5000.00);
BEGIN TRAN;
UPDATE BankAccount SET Balance=Balance-3000 WHERE AccountNo=101;
UPDATE BankAccount SET Balance=Balance+3000 WHERE AccountNo=102;
IF EXISTS(SELECT 1 FROM BankAccount WHERE AccountNo=101 AND Balance<0)
BEGIN
PRINT 'Balance went negative, rolling back transaction';
ROLLBACK TRAN;
END
ELSE
BEGIN
PRINT 'Transfer successful, committing transaction';
COMMIT TRAN;
END;
SELECT * FROM BankAccount;
GO
BEGIN TRAN;
UPDATE BankAccount SET Balance=Balance-30000 WHERE AccountNo=101;
UPDATE BankAccount SET Balance=Balance+30000 WHERE AccountNo=102;
IF EXISTS(SELECT 1 FROM BankAccount WHERE AccountNo=101 AND Balance<0)
BEGIN
PRINT 'Balance went negative, rolling back transaction';
ROLLBACK TRAN;
END
ELSE
BEGIN
PRINT 'Transfer successful, committing transaction';
COMMIT TRAN;
END;
SELECT * FROM BankAccount;
GO

--2) Using SAVEPOINT: Insert three new records into a table Orders. Rollback only the second insert using SAVEPOINT, then commit remaining

BEGIN TRAN;
INSERT INTO TxnOrders VALUES(7,907,'Pen',2);
SAVE TRAN Save1;
INSERT INTO TxnOrders VALUES(8,908,'Pencil',3);
SAVE TRAN Save2;
INSERT INTO TxnOrders VALUES(9,909,'Notepad',1);
SAVE TRAN Save3;
ROLLBACK TRAN Save2;
COMMIT TRAN;
SELECT*FROM TxnOrders;


--3) Handling Errors with TRY...CATCH: update prices in Products, force divide-by-zero, rollback and log error in ErrorLog

CREATE TABLE TxnProducts(ProductId INT PRIMARY KEY,ProductName VARCHAR(50),Price DECIMAL(10,2));
INSERT INTO TxnProducts VALUES(1,'Books',500.00),(2,'Mobile',15000.00),(3,'Laptop',45000.00);
CREATE TABLE TxnErrorLog(ErrorId INT IDENTITY(1,1) PRIMARY KEY,ErrorMessage NVARCHAR(4000),ErrorDate DATETIME);
BEGIN TRY
BEGIN TRAN;
UPDATE TxnProducts SET Price=Price+(Price*0.10);
DECLARE @x INT=0,@y INT;
SET @y=100/@x;
COMMIT TRAN;
END TRY
BEGIN CATCH
IF @@TRANCOUNT>0 ROLLBACK TRAN;
INSERT INTO TxnErrorLog(ErrorMessage,ErrorDate) VALUES(ERROR_MESSAGE(),GETDATE());
PRINT 'Error occurred, transaction rolled back';
END CATCH;
SELECT * FROM TxnProducts;
SELECT * FROM TxnErrorLog;
GO


--4) Nested Transactions: outer inserts customer, inner inserts order, force error in inner and observe rollback

CREATE TABLE TxnCustomer(CustId INT PRIMARY KEY,CustName VARCHAR(50));
CREATE TABLE TxnCustomerOrder(OrderId INT PRIMARY KEY,CustId INT,Product VARCHAR(50));
BEGIN TRY
BEGIN TRAN OuterTran;
INSERT INTO TxnCustomer VALUES(1,'Anvith');
BEGIN TRAN InnerTran;
INSERT INTO TxnCustomerOrder VALUES(1001,1,'Books');
INSERT INTO TxnCustomerOrder VALUES(1001,1,'Mobile');
COMMIT TRAN InnerTran;
COMMIT TRAN OuterTran;
END TRY
BEGIN CATCH
WHILE @@TRANCOUNT>0 ROLLBACK TRAN;
PRINT 'Error in inner transaction, all changes rolled back';
END CATCH;
SELECT * FROM TxnCustomer;
SELECT * FROM TxnCustomerOrder;
GO


--5) Isolation Level Dirty Read: Session 1 open transaction and update row without commit
-- (62, 63 windows)
CREATE TABLE IsoAccount(AccNo INT PRIMARY KEY,HolderName VARCHAR(50),Balance DECIMAL(10,2));
INSERT INTO IsoAccount VALUES(1,'Anvith',10000.00);
BEGIN TRAN;
UPDATE IsoAccount SET Balance=Balance+5000 WHERE AccNo=1;
SELECT * FROM IsoAccount;
--keep transaction open; in Session 2 run dirty read query, then finally ROLLBACK TRAN; in Session 1

--5) Isolation Level Dirty Read: Session 2 read with READ UNCOMMITTED
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT * FROM IsoAccount;



--6) Isolation Level Non-repeatable Read: Session 1 read same row twice inside transaction
-- (53,55)
BEGIN TRAN;
SELECT * FROM IsoAccount WHERE AccNo=1;

--now Session 2 will update and commit the same row
WAITFOR DELAY '00:00:10';
SELECT * FROM IsoAccount WHERE AccNo=1;
COMMIT TRAN;



--6) Isolation Level Non-repeatable Read: Session 2 update between reads
UPDATE IsoAccount SET Balance=Balance+2000 WHERE AccNo=1;
GO


--7) Isolation Level Phantom Read: create Sales table and show phantom rows
-- (71,72)
CREATE TABLE TxnSales(SaleId INT PRIMARY KEY,SaleDate DATE,Amount DECIMAL(10,2));
INSERT INTO TxnSales VALUES(1,'2024-01-10',1000),(2,'2024-01-20',1500);

--Session 1
BEGIN TRAN;
SELECT * FROM TxnSales WHERE SaleDate BETWEEN '2024-01-01' AND '2024-01-31';
WAITFOR DELAY '00:00:10';
SELECT * FROM TxnSales WHERE SaleDate BETWEEN '2024-01-01' AND '2024-01-31';
COMMIT TRAN;
GO

--Session 2 insert new row in same range
INSERT INTO TxnSales VALUES(3,'2024-01-15',2000);
GO


--8) Savepoint with Partial Rollback: update 5 employee salaries and rollback to savepoint 3

CREATE TABLE TxnEmployees(EmpId INT PRIMARY KEY,EmpName VARCHAR(50),Salary DECIMAL(10,2));
INSERT INTO TxnEmployees VALUES(1,'E1',30000),(2,'E2',32000),(3,'E3',34000),(4,'E4',36000),(5,'E5',38000);
BEGIN TRAN;
UPDATE TxnEmployees SET Salary=Salary+1000 WHERE EmpId=1;
SAVE TRAN S1;
UPDATE TxnEmployees SET Salary=Salary+1000 WHERE EmpId=2;
SAVE TRAN S2;
UPDATE TxnEmployees SET Salary=Salary+1000 WHERE EmpId=3;
SAVE TRAN S3;
UPDATE TxnEmployees SET Salary=Salary+1000 WHERE EmpId=4;
SAVE TRAN S4;
UPDATE TxnEmployees SET Salary=Salary+1000 WHERE EmpId=5;
SAVE TRAN S5;
ROLLBACK TRAN S3;
COMMIT TRAN;
SELECT * FROM TxnEmployees;
GO


--9) Insert multiple product records using a single transaction, force error so none are inserted

CREATE TABLE TxnMultiProduct(ProductId INT PRIMARY KEY,ProductName VARCHAR(50),Price DECIMAL(10,2));
BEGIN TRY
BEGIN TRAN;
INSERT INTO TxnMultiProduct VALUES(1,'Books',500.00);
INSERT INTO TxnMultiProduct VALUES(2,'Mobile',15000.00);
INSERT INTO TxnMultiProduct VALUES(2,'Laptop',45000.00);
COMMIT TRAN;
END TRY
BEGIN CATCH
IF @@TRANCOUNT>0 ROLLBACK TRAN;
PRINT 'Error in one insert, full transaction rolled back';
END CATCH;
SELECT * FROM TxnMultiProduct;
GO


--10) Savepoint in TRY...CATCH: insert 3 orders with savepoints, keep first 2 after error

CREATE TABLE TxnOrders2(OrderId INT PRIMARY KEY,CustId INT,Product VARCHAR(50),Qty INT);
BEGIN TRY
BEGIN TRAN;
INSERT INTO TxnOrders2 VALUES(201,901,'Books',2);
SAVE TRAN P1;
INSERT INTO TxnOrders2 VALUES(202,901,'Mobile',1);
SAVE TRAN P2;
INSERT INTO TxnOrders2 VALUES(201,901,'Laptop',1);
SAVE TRAN P3;
COMMIT TRAN;
END TRY
BEGIN CATCH
IF @@TRANCOUNT>0
BEGIN
ROLLBACK TRAN P2;
COMMIT TRAN;
END;
PRINT 'Error before third insert, kept first two records using savepoint';
END CATCH;
SELECT * FROM TxnOrders2;
GO