-- TRIGGERS

triggers (delete trigger)

create trigger tr1 on newstudentstbl
for delete
as
if exists(select * from deleted where studentname='madavi')
begin
print ' u cannot delete this record'
rollback
end

======================================================
select * from sysobjects where xtype='U'-- lists all tables

select * from sysobjects where xtype='V'-- lists all views

select * from sysobjects where xtype='PK'-- lists all primary key

select * from syscomments--- lists all source code
=======================================================

insert  trigger 
----------------
create trigger tr2 on newstudentstbl
for insert
as
begin
if exists(select * from inserted where age < 18)
begin
rollback transaction
print 'age cannot be less than 18'
end
end
===================================================
update trigger
create trigger tr3 on newstudentstbl
for update
as
begin
select * from inserted
select * from deleted
end
============================================

--alter trigger tr1 on newstudentstbl
--for insert
--as
--if(@@ROWCOUNT > 1)--deleted table 
--begin
--print 'you cannot delete more than 1 record at a time'
--rollback transaction
--end

--------------------------------------------------------------
how to enable and disble trigger
----------------------------------
Disable a Particular Trigger:

Syntax:
ALTER TABLE Table_Name DISABLE TRIGGER Trigger_Name
 
Example:
ALTER TABLE Employee DISABLE TRIGGER TR_Insert_Salary
---------------------------------------------------------------------------
Enable a Particular Trigger:

Syntax:
ALTER TABLE Table_Name ENABLE TRIGGER Trigger_Name
 
Example:
ALTER TABLE Employee ENABLE TRIGGER TR_Insert_Salary
--------------------------------------------------------------------------
Disable All Trigger of a table:
We can disable and enable all triggers of a table using previous query, but replacing the "ALL" instead of trigger name.

Syntax:
ALTER TABLE Table_Name DISABLE TRIGGER ALL 
 
Example:
ALTER TABLE Demo DISABLE TRIGGER ALL
------------------------------------------------------------------------------------
Enable All Trigger of a table:

Syntax:

ALTER TABLE Table_Name ENABLE TRIGGER ALL
 
Example:

ALTER TABLE Demo ENABLE  TRIGGER ALL
-----------------------------------------------------------------------------
Disable All Trigger for database:
Using sp_msforeachtable system stored procedure we enable and disable all triggers for a database.
 
Syntax: 

Use Database_Name 
Exec sp_msforeachtable "ALTER TABLE ? DISABLE TRIGGER all"
 
Example:

Use Demo
Exec sp_msforeachtable "ALTER TABLE ? DISABLE TRIGGER all"

-----------------------------------------------------------------------------
 
Enable All Trigger for database:
Syntax:

Use Database_Name
Exec sp_msforeachtable "ALTER TABLE ? ENABLE TRIGGER all"
 
Example:

Use Demo
Exec sp_msforeachtable "ALTER TABLE ? ENABLE TRIGGER all"

-------------------------------------------------------------------------------
Trigger Execution order

EXEC sys.sp_settriggerorder @triggername = 'TRIGGER_FIRST',  
   @order = 'FIRST',  
   @stmttype = 'INSERT',  
   @namespace = NULL  
Now we set the order of TRIGGER_SECOND.
EXEC sys.sp_settriggerorder @triggername = 'TRIGGER_SECOND',  
   @order = 'LAST',  
   @stmttype = 'INSERT',  
   @namespace = NULL  
----------------------------------------------------------------
insert of keyword and views
create table a
(
custid int,
custname varchar(12)
)
create table b
(
custid int,
product varchar(12)
)
create view testview
as
select a.* , b.product from a inner join b on a.custid = b.custid
select * from testview

Create trigger tr
on testview  
Instead Of Insert  
as  
Begin  
insert into A (custid,custname)
Select custid, custname from inserted  

insert into b (custid,product)
Select custid,product from inserted
End
insert into testview values(1,'ajay','books')
select * from a
select * from b
------------------------------------
create table a1
(
custid int,
custname varchar(12)
)
create trigger tr
on a1  
Instead Of Insert  
as  
Begin 
insert into a1  select custid , left(custname,2) from inserted
end

insert into a1 values(1,'vijay')
===================================
alter trigger mytrig1 on newstudentstbl
instead of insert
as
begin
-- u have to manully write insert command inside the trigger
insert into  newstudentstbl select studentid,upper(studentname),age,upper(saddress) from inserted
end

-- it will not be inserted
insert into newstudentstbl values(1200,'kanishka',23,'chennai')
=================================================================






